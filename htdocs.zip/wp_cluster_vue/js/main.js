class App {
    renderPlatforms () {
        let aPlatforms = this.config.cloudPlatforms,
            html = aPlatforms.map(oPlatform => {

            return `
                <div class="platform">
                    <img src="${oPlatform.imgUrl}" alt="">
                    <p>${oPlatform.name}</p>
                </div>
            `
        });

        $('.platform-grid').html(html);
    }

    renderRegions(aRegions) {
        let html = aRegions.map(sRegion => {
            return `
                <div class="region">
                    <p>${sRegion.name}</p>
                    <img src="${sRegion.imgUrl}" alt="">
                </div>
            `
        });

        $('.pick-region-grid').html(html);
    }

    setActivePlatform (sName) {
        let regions;

        this.config.cloudPlatforms.forEach(oPlatform => {
            if (oPlatform.name === sName) {
                regions = oPlatform.regions;
            }
        });


    }

    getConfig (fCallback) {
        $.ajax({
            url         : "js/config.js",
            success     : fCallback,
            cache       : false,
            dataType    : "json"
        })
    }
}

jQuery(document).ready(function ($) {
    var sTpl = $('body').html(),
        app = new App(),
        sBody,
        oConfig;

    app.getConfig(function (oInitialConfig) {
        app.config = oInitialConfig;
        app.renderPlatforms(oInitialConfig.cloudPlatforms);

        //app.setActivePlatform(oInitialConfig.defaultPlatform)
        $('.platform').click(function () {
            debugger;
        })
    });
})