class App {
    renderPlatforms () {
        let aPlatforms = this.config.cloudPlatforms,
            html = aPlatforms.map(oPlatform => {

            return `
                <div class="platform" data-name="${oPlatform.name}">
                    <img src="${oPlatform.imgUrl}" alt="">
                    <p>${oPlatform.name}</p>
                </div>
            `
        });

        $('.platform-grid').html(html);
    }

    renderRegions(aRegions) {
        let html;

        // aRegions = aRegionIds.map(sRegion => {
        //     return {
        //         name    : this.config.countries[sRegion][0],
        //         imgUrl  : ""
        //     }
        // })

        html = aRegions.map(sRegion => {
            return `
                <div class="region" data-name="${sRegion.name}">
                    <p>${sRegion.name}</p>
                    <img src="${sRegion.imgUrl}" alt="">
                </div>
            `
        });

        $('.pick-region-grid').html(html);
    }

    renderServicePlans () {
        let html;

        html = this.config.servicePlans.map(oPlan => {
            let oInfo = oPlan.info.map( sInfo => `<p>${sInfo}</p>`);

            return `
                <div class="${oPlan.name.toLowerCase()} service-plan">
                     <div class="heading">${oPlan.name}</div>
                    <div class="content-part">
                        ${oInfo.join("")}
                    </div>
                  </div>

            `
        })

        $('.choose-package-grid').html(html);
    }

    setActiveItem (sItemCls) {

    }

    setActivePlatform (oSelected) {
        let sName = oSelected.data('name'),
            aRegions;

        this.config.cloudPlatforms.forEach(oPlatform => {
            if (oPlatform.name === sName) {
                aRegions = oPlatform.countries;
            }
        });

        this.renderRegions(aRegions);
        this.handleActiveCls('.region');
    }

    getConfig (fCallback) {
        $.ajax({
            url         : "js/config.js",
            success     : fCallback,
            cache       : false,
            dataType    : "json"
        })
    }

    handleActiveCls(sItemCls) {
        $(sItemCls).click(function () {
            $(sItemCls + '.active-item').removeClass('active-item');
            $(this).addClass('active-item');
        });

    }

    renderPackageVersions () {
        let html = this.config.packageVersions.map(sVersion => `<p class="package-version">${sVersion}</p>`);

        $('.versions').html(html);

        $('.specify-version h3').html(this.config.packageVersionsSubTitle);
    }

    renderTitle () {
        let oCfg = this.config;
        $('.title').html(`${oCfg.packageTitle} <span>${oCfg.packageSubTitle}</span>`);
    }

    handleSubmit(oBtn, e) {
        let me = this,
            oCfg = me.config,
            oData = {};

        e.preventDefault();

        oBtn.html(oCfg.btnTextProgress);

        $.ajax({
            url     : oCfg.submitUrl,
            data    : oData,
            method  : "POST",
            dataType: "json",
            success : function () {
                oBtn.html(oCfg.btnTextSuccess);
            },
            error   : function () {
                oBtn.html(oCfg.btnTextError);
            }
        })
    }

    renderSubmitBtn () {
        let me = this,
            oBtn = $('.submit');

        oBtn.html(me.config.btnTextSubmit);

        oBtn.click(function(e) {
            me.handleSubmit($(this),e);
        });

    }

    renderPage (oCfg) {
        let me = this;

        me.config = oCfg;

        me.renderTitle();
        me.renderPlatforms();
        me.renderPackageVersions();
        me.renderServicePlans();

        me.setActivePlatform($(`[data-name="${oCfg.defaultPlatform}"]`));

        me.renderSubmitBtn();

        $('.platform').click(function () {
            me.setActivePlatform($(this));
        });

        me.handleActiveCls('.platform');
        me.handleActiveCls('.service-plan');
        me.handleActiveCls('.package-version');
    }
}

jQuery(document).ready(function ($) {
    var sTpl = $('body').html(),
        app = new App(),
        sBody,
        oConfig;

    app.getConfig(function (oCfg) {
        app.renderPage(oCfg);
    });
})