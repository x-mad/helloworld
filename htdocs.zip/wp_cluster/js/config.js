{

    "packageTitle" : "WordPress-as-a-Service",
    "packageSubTitle" : "High Performance Available for Everyone",

    "defaultPlatform" : "Jelastic Union",

    "cloudPlatforms": [{
            "name"      : "Jelastic Union",
            "imgUrl"    : "img/jelastic-union.svg",
            "countries" : [{
                "name":"Ukraine",
                "imgUrl":""
            }, {
                "name":"USA",
                "imgUrl":""
            }, {
                "name": "Spain",
                "imgUrl":""
            }]
        }, {
            "name"      : "Google Cloud Platform",
            "imgUrl"    : "img/google-cloud.svg",
            "countries" : [{
                "name":"Greece",
                "imgUrl":""
            }, {
                "name":"Fiji",
                "imgUrl":""
            }, {
                "name": "Russia",
                "imgUrl":""
            }]
        }, {
            "name"      : "Amazon Web Services",
            "imgUrl"    : "img/amazon-web-services.svg",
            "countries" : [{
                "name":"Fiji",
                "imgUrl":""
            }, {
                "name":"Russia",
                "imgUrl":""
            }, {
                "name": "Spain",
                "imgUrl":""
            }]
        }, {
            "name"      : "Microsoft Azure",
            "imgUrl"    : "img/microsoft-azure.svg",
            "countries" : [{
                "name":"Spain",
                "imgUrl":""
            }, {
                "name":"USA",
                "imgUrl":""
            }, {
                "name": "Spain",
                "imgUrl":""
            }]
        }, {
            "name"      : "Digital Ocean",
            "imgUrl"    : "img/digitalocean.svg",
            "countries" : [{
                "name":"USA",
                "imgUrl":""
            }, {
                "name":"Spain",
                "imgUrl":""
            }, {
                "name": "Greece",
                "imgUrl":""
            }]
        }],

    "packageVersions" : ["3.7.4", "4.6.12", "4.8.1"],
    "packageVersionsSubTitle" : "Wordpress Version",

    "servicePlans" : [{
        "name" : "Enterprise",
        "info" : [
            "Multi-Cloud Dedicated Cluster",
            "X Regions, Y Clusters, Custom Cluster Topology",
            "100GB+ of Local Storage",
            "400GB+ of Bandwidth per Month",
            "GlusterFS",
            "Global CDN",
            "Anycast DNS",
            "Geo-Routing",
            "WAF",
            "ADN"
        ]
    }, {
        "name"  : "Premium",
        "info"  : [
            "Multi-Cloud Dedicated Cluster",
            "2 Regions, 2 Clusters, 16 containers",
            "100GB of Local Storage",
            "400GB of Bandwidth per Month",
            "GlusterFS",
            "Global CDN",
            "Anycast DNS",
            "Geo-Routing",
            "WAF"
        ]
    }, {
        "name" : "Business",
        "info" : [
            "Dedicated Cluster",
            "1 Region, 1 Cluster, 6 containers",
            "50GB of Local Storage",
            "200GB of Bandwidth per Month",
            "Global CDN",
            "Anycast DNS"
        ]
    }, {
        "name"  : "Startup",
        "info"  : [
            "Dedicated Stanalone",
            "1 Region, 2 containers",
            "10GB of Local Storage",
            "50GB of Bandwidth per Month",
            "Global CDN"
        ]
    }],

    "btnTextSubmit"      : "Create Deployment",
    "btnTextProgress"    : "In Progress",
    "btnTextSuccess"     : "Ready! Get Started",
    "btnTextError"       : "Oops! Error Occured",

    "submitUrl"          : "https://google.com"
}

