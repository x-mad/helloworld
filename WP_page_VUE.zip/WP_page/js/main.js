var app = new Vue({
    el      : '#app',

    data    : {
        config : {},
        deploymentName: "",
        activeItems: {
            platform: "",
            region: "",
            packageVersion: "",
            servicePlan: ""
        }
    },

    methods : {
        init : function () {
            this.activeItems.platform = this.config.cloudPlatforms[0];
        },

        setActiveItem: function () {
            console.log('33');
        },

        submitForm : function () {
            fetch(this.config.submitUrl);
        }
    },

    mounted : function () {
        fetch('js/config.js')
            .then( response => response.json())
            .then(config => this.config = config)
            .then(this.init)
            .catch(error => console.log(error));
    }
});

