{
    "packageTitle": "WordPress-as-a-Service",
    "packageSubTitle": "High Performance Available for Everyone",
    "defaultPlatform": "Jelastic Union",
    "cloudPlatforms": [
    {
        "name": "Jelastic Union",
        "imgUrl": "img/jelastic-union.svg",
        "countries": [
            {
                "name": "Ukraine",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "USA",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Spain",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            }
        ]
    },
    {
        "name": "Google Cloud Platform",
        "imgUrl": "img/google-cloud.svg",
        "countries": [
            {
                "name": "Greece",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Fiji",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Russia",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            }
        ]
    },
    {
        "name": "Amazon Web Services",
        "imgUrl": "img/amazon-web-services.svg",
        "countries": [
            {
                "name": "Fiji",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Russia",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Spain",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Greece",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            }
        ]
    },
    {
        "name": "Microsoft Azure",
        "imgUrl": "img/microsoft-azure.svg",
        "countries": [
            {
                "name": "Spain",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "USA",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Austria",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            }
        ]
    },
    {
        "name": "Digital Ocean",
        "imgUrl": "img/digitalocean.svg",
        "countries": [
            {
                "name": "USA",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Spain",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            },
            {
                "name": "Greece",
                "imgUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAExSURBVHja1JY9TgMxEIW/2XhDxEYEWiQEJWdAnICegqPRU3ARxDUiIWp+oiwh9sxQZJ2/2ouU19gaS+953rNsi7vTJyp6Ru8CAgRgBNSFuSOwCMD4/f7hQwaD4rs/f346C0AjVcXo9qYo+eLlFaAJQDBVWC6xr2/cHREhny4RAdip79fyfB3s5AQzAwgBwGPC5i3WtoDgeBeP4924qtPVNlit78LrIZ4SdAFjmvD2B5+3RezxEPCk61N0GWOchlUzxZBSoq7rqwrIfhVF5qz2AyqFzPk/HRy0RQHg+u4RkyGz+bII+bgZUkvcCCRVvDLUvJg90XVLICoEsEICqmC6JaDmVDjNcZkb23G0CzkAMSZF0qyP9yYKMAEugNPC5J/AW37RjrJdJa8j4FcO/lfxNwBleqag/5PB9AAAAABJRU5ErkJggg=="
            }
        ]
    }
],
    "packageVersions": [
    "3.7.4",
    "4.6.12",
    "4.8.1"
],
    "packageVersionsSubTitle": "Wordpress Version",
    "servicePlans": [
    {
        "name": "Enterprise",
        "info": [
            "Multi-Cloud Dedicated Cluster",
            "X Regions, Y Clusters, Custom Cluster Topology",
            "100GB+ of Local Storage",
            "400GB+ of Bandwidth per Month",
            "GlusterFS",
            "Global CDN",
            "Anycast DNS",
            "Geo-Routing",
            "WAF",
            "ADN"
        ]
    },
    {
        "name": "Premium",
        "info": [
            "Multi-Cloud Dedicated Cluster",
            "2 Regions, 2 Clusters, 16 containers",
            "100GB of Local Storage",
            "400GB of Bandwidth per Month",
            "GlusterFS",
            "Global CDN",
            "Anycast DNS",
            "Geo-Routing",
            "WAF"
        ]
    },
    {
        "name": "Business",
        "info": [
            "Dedicated Cluster",
            "1 Region, 1 Cluster, 6 containers",
            "50GB of Local Storage",
            "200GB of Bandwidth per Month",
            "Global CDN",
            "Anycast DNS"
        ]
    },
    {
        "name": "Startup",
        "info": [
            "Dedicated Stanalone",
            "1 Region, 2 containers",
            "10GB of Local Storage",
            "50GB of Bandwidth per Month",
            "Global CDN"
        ]
    }
],
    "btnTextSubmit": "Create Deployment",
    "btnTextProgress": "In Progress",
    "btnTextSuccess": "Ready! Get Started",
    "btnTextError": "Oops! Something  wrong",
    "submitUrl": "https://app.madrid.central.jelastic.team"
}